"""
Current version (short and full names).
"""

__version_short__ = '1.0'
__version_full__ = '1.0.2'

__version__ = __version_full__